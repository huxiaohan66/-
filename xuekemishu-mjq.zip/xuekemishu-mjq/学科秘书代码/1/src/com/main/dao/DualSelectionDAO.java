package com.main.dao;

import java.sql.*;

import com.main.connect.JDBCUtils;

public class DualSelectionDAO {
	// 更新轮次状态
	public void updateRoundStatus(int round, int status) throws Exception {
	    String column;
	    switch (round) {
	        case 1:
	            column = "一轮";
	            break;
	        case 2:
	            column = "二轮";
	            break;
	        case 3:
	            column = "三轮";
	            break;
	        default:
	            throw new IllegalArgumentException("Invalid round: " + round);
	    }
	    String sql = "UPDATE 轮次表 SET " + column + " = ?";

	    try (Connection con = JDBCUtils.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, status);
	        ps.executeUpdate();
	    }
	}


    // 第二轮排序存储过程
    public void sortRoundTwoMentors(String collegeId) throws Exception {
        try (Connection con = JDBCUtils.getConnection();
             CallableStatement cs = con.prepareCall("{call SortRoundTwoMentors(?)}")) {
            cs.setString(1, collegeId);
            cs.execute();
        }
    }

    // 第三轮排序存储过程
    public void sortRoundThreeMentors(String collegeId) throws Exception {
        try (Connection con = JDBCUtils.getConnection();
             CallableStatement cs = con.prepareCall("{call SortRoundThreeMentors(?)}")) {
            cs.setString(1, collegeId);
            cs.execute();
        }
    }
}
