package com.main.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.main.dao.StudentDAO;
import com.main.model.Student;

@WebServlet("/StudentProfileServlet")
public class StudentProfileServlet extends HttpServlet {

	private StudentDAO studentDao = new StudentDAO();
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String examId = request.getParameter("examId");
        
        if (examId != null) {
            Student student = studentDao.getStudentByExamId(examId); // 需要在 StudentDao 中实现该方法
            request.setAttribute("student", student);
            request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
        } else {
            response.sendRedirect("StudentDetails.jsp");
        }
    }


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
