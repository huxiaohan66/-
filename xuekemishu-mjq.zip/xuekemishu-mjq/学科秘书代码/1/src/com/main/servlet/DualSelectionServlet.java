package com.main.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.main.dao.DualSelectionDAO;

@WebServlet("/DualSelectionServlet")
public class DualSelectionServlet extends HttpServlet {

	private DualSelectionDAO dualSelectionDao = new DualSelectionDAO();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String action = request.getParameter("action");
	    String roundParam = request.getParameter("round");
	    System.out.println("Received round parameter: " + roundParam); // 调试输出
	    
	    if (roundParam == null || roundParam.isEmpty()) {
	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Round parameter is missing.");
	        return;
	    }
	    int round = Integer.parseInt(roundParam);

	    if (roundParam != null && !roundParam.isEmpty()) {
	        try {
	            round = Integer.parseInt(roundParam);
	        } catch (NumberFormatException e) {
	            e.printStackTrace();
	            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid round parameter.");
	            return;
	        }
	    } else {
	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Round parameter is missing.");
	        return;
	    }

	    String collegeId = (String) request.getSession().getAttribute("collegeId");

	    try {
	        if ("start".equals(action)) {
	            dualSelectionDao.updateRoundStatus(round, 1); // 设置轮次为进行中
	        } else if ("end".equals(action)) {
	            dualSelectionDao.updateRoundStatus(round, 2); // 设置轮次为已结束
	        } else if ("sort".equals(action)) {
	            if (round == 2) {
	                dualSelectionDao.sortRoundTwoMentors(collegeId); // 第二轮排序
	            } else if (round == 3) {
	                dualSelectionDao.sortRoundThreeMentors(collegeId); // 第三轮排序
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    request.getRequestDispatcher("DualSelectionProcess.jsp").forward(request, response);
	}

}
