package com.main.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.main.dao.ResultDAO;
import com.main.model.DualSelectionResult;

@WebServlet("/DualSelectResultServlet")
public class DualSelectResultServlet extends HttpServlet {

	private ResultDAO resultDao = new ResultDAO();
	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<DualSelectionResult> results = resultDao.getAllDualSelectionResults();
        request.setAttribute("results", results);
        request.getRequestDispatcher("/DualSelectionResults.jsp").forward(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
