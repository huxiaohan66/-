package com.main.connect;

import java.sql.*;

public class JDBCUtils {
	//获取数据库连接
    public static Connection getConnection() throws Exception {
        //加载sql类及其驱动器
        Class clazz = Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=数据库课设;encrypt=false;characterEncoding=UTF-8";
        Connection con = DriverManager.getConnection(url, "sa", "1");
        //System.out.println("连接成功");
        return con;
    }


    //关闭连接和信使
    public static void closeResource(Connection con, PreparedStatement ps) {
        try {
            if (ps != null)
                ps.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            if (con != null)
                con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //关闭连接，信使，结果集
    public static void closeResource(Connection con, PreparedStatement ps, ResultSet res) {
        try {
            if (ps != null)
                ps.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            if (con != null)
                con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            if (res != null)
                res.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
