package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connect.JDBCUtils;
import model.Mentor;

public class MentorDAO {
	// 获取所有导师信息
	public List<Mentor> getAllMentorsByCollege(String collegeId) {
        List<Mentor> mentors = new ArrayList<>();
        String sql = "SELECT 导师编号, 导师姓名, 学科编号, 导师指标, 缺额数 FROM 导师表 WHERE 学院编号 = ?";
        
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setString(1, collegeId);
            try (ResultSet rs = ps.executeQuery()) {
            	while (rs.next()) {
            	    Mentor mentor = new Mentor(
            	        rs.getString("导师编号").trim(),
            	        rs.getString("导师姓名").trim(),
            	        rs.getString("学科编号").trim(),
            	        rs.getInt("导师指标"),
            	        rs.getInt("缺额数")
            	    );
            	    mentors.add(mentor);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mentors;
    }
}