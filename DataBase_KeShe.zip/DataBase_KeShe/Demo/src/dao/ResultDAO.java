package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import connect.JDBCUtils;
import model.DualSelectionResult;

public class ResultDAO {
	public List<DualSelectionResult> getAllDualSelectionResults() {
        List<DualSelectionResult> results = new ArrayList<>();
        String sql = "SELECT f.学科编号, f.学生姓名, f.导师编号, t.导师姓名 " +
                     "FROM 学生导师匹配视图 f " +
                     "JOIN 导师信息表 t ON f.导师编号 = t.导师编号";

        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DualSelectionResult result = new DualSelectionResult();
                result.setDisciplineId(rs.getString("学科编号"));
                result.setStudentName(rs.getString("学生姓名"));
                result.setMentorId(rs.getString("导师编号"));
                result.setMentorName(rs.getString("导师姓名"));
                results.add(result);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }
}
