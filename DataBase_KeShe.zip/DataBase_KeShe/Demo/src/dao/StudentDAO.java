package dao;

import model.Student;
import connect.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    
    public List<Student> getStudentsByCollege(String collegeId) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT s.考生姓名, s.身份证号, s.生源地, s.本科专业, s.出生日期, " +
                     "s.考生准考证号, s.邮箱, s.电话, s.本科学校, s.个人简历, s.本科学校类型, " +
                     "s.性别, s.本科毕业时间, s.考生类别, s.报考学院编号, s.报考学科编号, " +
                     "z.导师姓名_第一志愿, z.导师姓名_第二志愿, z.导师姓名_第三志愿 " +
                     "FROM 学生表 s " +
                     "JOIN 学生志愿表 z ON s.考生准考证号 = z.学生编号 " +
                     "WHERE s.报考学院编号 = ?";
        
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setString(1, collegeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Student student = new Student();
                    student.setName(rs.getString("考生姓名"));
                    student.setIdNumber(rs.getString("身份证号"));
                    student.setOrigin(rs.getString("生源地"));
                    student.setUndergraduateMajor(rs.getString("本科专业"));
                    student.setBirthDate(rs.getDate("出生日期"));
                    student.setExamId(rs.getString("考生准考证号"));
                    student.setEmail(rs.getString("邮箱"));
                    student.setPhone(rs.getString("电话"));
                    student.setUndergraduateSchool(rs.getString("本科学校"));
                    student.setResume(rs.getString("个人简历"));
                    student.setSchoolType(rs.getString("本科学校类型"));
                    student.setGender(rs.getString("性别"));
                    student.setGraduationDate(rs.getDate("本科毕业时间"));
                    student.setCategory(rs.getString("考生类别"));
                    student.setCollegeId(rs.getString("报考学院编号"));
                    student.setDisciplineId(rs.getString("报考学科编号"));
                    student.setFirstChoiceMentor(rs.getString("导师姓名_第一志愿"));
                    student.setSecondChoiceMentor(rs.getString("导师姓名_第二志愿"));
                    student.setThirdChoiceMentor(rs.getString("导师姓名_第三志愿"));
                    students.add(student);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return students;
    }
    
    public Student getStudentByExamId(String examId) {
        Student student = null;
        String sql = "SELECT s.考生姓名, s.身份证号, s.生源地, s.本科专业, s.出生日期, " +
                     "s.考生准考证号, s.邮箱, s.电话, s.本科学校, s.个人简历, s.本科学校类型, " +
                     "s.性别, s.本科毕业时间, s.考生类别, s.报考学院编号, s.报考学科编号, " +
                     "z.导师姓名_第一志愿, z.导师姓名_第二志愿, z.导师姓名_第三志愿 " +
                     "FROM 学生表 s " +
                     "JOIN 学生志愿表 z ON s.考生准考证号 = z.学生编号 " +
                     "WHERE s.考生准考证号 = ?";
        
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setString(1, examId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    student = new Student();
                    student.setName(rs.getString("考生姓名"));
                    student.setIdNumber(rs.getString("身份证号"));
                    student.setOrigin(rs.getString("生源地"));
                    student.setUndergraduateMajor(rs.getString("本科专业"));
                    student.setBirthDate(rs.getDate("出生日期"));
                    student.setExamId(rs.getString("考生准考证号"));
                    student.setEmail(rs.getString("邮箱"));
                    student.setPhone(rs.getString("电话"));
                    student.setUndergraduateSchool(rs.getString("本科学校"));
                    student.setResume(rs.getString("个人简历"));
                    student.setSchoolType(rs.getString("本科学校类型"));
                    student.setGender(rs.getString("性别"));
                    student.setGraduationDate(rs.getDate("本科毕业时间"));
                    student.setCategory(rs.getString("考生类别"));
                    student.setCollegeId(rs.getString("报考学院编号"));
                    student.setDisciplineId(rs.getString("报考学科编号"));
                    student.setFirstChoiceMentor(rs.getString("导师姓名_第一志愿"));
                    student.setSecondChoiceMentor(rs.getString("导师姓名_第二志愿"));
                    student.setThirdChoiceMentor(rs.getString("导师姓名_第三志愿"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return student;
    }
}
