package model;

import java.util.Date;

public class Student {
	private String name;
    private String idNumber;
    private String origin;
    private String undergraduateMajor;
    private Date birthDate;
    private String examId;
    private String email;
    private String phone;
    private String undergraduateSchool;
    private String resume;
    private String schoolType;
    private String gender;
    private Date graduationDate;
    private String category;
    private String collegeId;
    private String disciplineId;
    private String firstChoiceMentor;
    private String secondChoiceMentor;
    private String thirdChoiceMentor;

    // Getters and Setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getUndergraduateMajor() {
        return undergraduateMajor;
    }

    public void setUndergraduateMajor(String undergraduateMajor) {
        this.undergraduateMajor = undergraduateMajor;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getExamId() {
        return examId;
    }

    public void setExamId(String examId) {
        this.examId = examId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUndergraduateSchool() {
        return undergraduateSchool;
    }

    public void setUndergraduateSchool(String undergraduateSchool) {
        this.undergraduateSchool = undergraduateSchool;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getGraduationDate() {
        return graduationDate;
    }

    public void setGraduationDate(Date graduationDate) {
        this.graduationDate = graduationDate;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCollegeId() {
        return collegeId;
    }

    public void setCollegeId(String collegeId) {
        this.collegeId = collegeId;
    }

    public String getDisciplineId() {
        return disciplineId;
    }

    public void setDisciplineId(String disciplineId) {
        this.disciplineId = disciplineId;
    }

    public String getFirstChoiceMentor() {
        return firstChoiceMentor;
    }

    public void setFirstChoiceMentor(String firstChoiceMentor) {
        this.firstChoiceMentor = firstChoiceMentor;
    }

    public String getSecondChoiceMentor() {
        return secondChoiceMentor;
    }

    public void setSecondChoiceMentor(String secondChoiceMentor) {
        this.secondChoiceMentor = secondChoiceMentor;
    }

    public String getThirdChoiceMentor() {
        return thirdChoiceMentor;
    }

    public void setThirdChoiceMentor(String thirdChoiceMentor) {
        this.thirdChoiceMentor = thirdChoiceMentor;
    }

}
