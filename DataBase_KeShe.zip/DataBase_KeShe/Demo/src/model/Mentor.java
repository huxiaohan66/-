package model;

public class Mentor {
	private String mentorId;
    private String mentorName;
    private String discipline1;
    private int mentorQuota;
    private int vacancy;

    public Mentor(String mentorId, String mentorName, String discipline1, int mentorQuota, int vacancy) {
        this.mentorId = mentorId;
        this.mentorName = mentorName;
        this.discipline1 = discipline1;
        this.mentorQuota = mentorQuota;
        this.vacancy = vacancy;
    }
    
    // Getters and setters
    public String getMentorId() { return mentorId; }
    public void setMentorId(String mentorId) { this.mentorId = mentorId; }

    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }

    public String getDiscipline1() { return discipline1; }
    public void setDiscipline1(String discipline1) { this.discipline1 = discipline1; }

    public int getMentorQuota() { return mentorQuota; }
    public void setMentorQuota(int mentorQuota) { this.mentorQuota = mentorQuota; }

    public int getVacancy() { return vacancy; }
    public void setVacancy(int vacancy) { this.vacancy = vacancy; }
}
