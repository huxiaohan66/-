package model;

public class DualSelectionResult {
	private String disciplineId;
    private String studentName;
    private String mentorId;
    private String mentorName;

    // Getters and Setters
    public String getDisciplineId() { return disciplineId; }
    public void setDisciplineId(String disciplineId) { this.disciplineId = disciplineId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getMentorId() { return mentorId; }
    public void setMentorId(String mentorId) { this.mentorId = mentorId; }

    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }

}
