package teacher;

import connect.JDBCUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MentorDAOImpl implements MentorDAO {

    @Override
    public Mentor getMentorById(String mentorId) {
        Mentor mentor = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet res = null;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT 导师编号, 导师姓名 , 导师职称 , 所在学科1 , 所在学科2 , 所在学科3 , " +
                    "导师电话 , 导师邮箱 , 导师简介 , 导师图片 , 学院表.学院名称 " +
                    "FROM dbo.导师信息表 " +
                    "INNER JOIN  学院表 ON 学院表.学院编号=导师信息表.所属学院 " +
                    "WHERE 导师编号 = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, mentorId);
            res = ps.executeQuery();
            if (res.next()) {
                mentor = new Mentor();
                mentor.setMentorId(res.getString("导师编号"));
                mentor.setName(res.getString("导师姓名"));
                mentor.setTitle(res.getString("导师职称"));
                mentor.setDepartment1(res.getString("所在学科1"));
                mentor.setDepartment2(res.getString("所在学科2"));
                mentor.setDepartment3(res.getString("所在学科3"));
                mentor.setPhone(res.getString("导师电话"));
                mentor.setEmail(res.getString("导师邮箱"));
                mentor.setBio(res.getString("导师简介"));
                mentor.setImage(res.getString("导师图片"));
                mentor.setCollege(res.getString("学院名称"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, res);
        }
        return mentor;
    }

    @Override
    public void updateMentor(Mentor mentor) {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            con = JDBCUtils.getConnection();
            String sql = "UPDATE dbo.导师信息表 SET " +
                    "导师姓名 = ?, 导师职称 = ?, 所在学科1 = ?, 所在学科2 = ?, 所在学科3 = ?, " +
                    "导师电话 = ?, 导师邮箱 = ?, 导师简介 = ? " +
                    "WHERE 导师编号 = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, mentor.getName());
            ps.setString(2, mentor.getTitle());
            ps.setString(3, mentor.getDepartment1());
            ps.setString(4, mentor.getDepartment2());
            ps.setString(5, mentor.getDepartment3());
            ps.setString(6, mentor.getPhone());
            ps.setString(7, mentor.getEmail());
            ps.setString(8, mentor.getBio());
            ps.setString(9, mentor.getMentorId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps);
        }
    }

    @Override
    public List<RecruitmentInfo> getRecruitmentInfoByTeacherId(String teacherId) throws SQLException {
        List<RecruitmentInfo> recruitmentInfos = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = JDBCUtils.getConnection();
            // 视图查找
            String sql = "SELECT * " +
                    "FROM 导师招生信息视图 " +
                    "WHERE 导师编号 = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, teacherId);
            rs = ps.executeQuery();

            while (rs.next()) {
                RecruitmentInfo info = new RecruitmentInfo();
                info.setTeacherId(teacherId);
                info.setTeacherName(rs.getString("导师姓名"));
                info.setCollegeId(rs.getString("学院编号"));
                info.setSubjectId(rs.getString("学科编号"));
                info.setTeacherIdentity(rs.getString("导师身份"));
                info.setQuota(rs.getInt("导师指标"));
                info.setVacancy(rs.getInt("缺额数"));
                info.setSubjectName(rs.getString("学科名称"));
                info.setCollegeName(rs.getString("学院名称"));
                recruitmentInfos.add(info);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return recruitmentInfos;
    }

    @Override
    public List<StudentAC> getAllStudentsByCollegeId(String collegeId) {
        List<StudentAC> studentACs = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT * FROM 复试通过学生名单 WHERE 学院编号 = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, collegeId);
            rs = ps.executeQuery();

            while (rs.next()) {
                String studentId = rs.getString("学生编号");
                String studentName = rs.getString("学生姓名");
                String subjectId = rs.getString("学科编号");
                String subjectName = rs.getString("学科名称");
                StudentAC studentAC = new StudentAC(studentId, studentName, subjectId, subjectName, collegeId);
                studentACs.add(studentAC);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return studentACs;
    }

}
