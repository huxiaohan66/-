package teacher;



import java.sql.SQLException;
import java.util.List;

public interface MentorDAO {
    Mentor getMentorById(String mentorId);  //查看信息
    void updateMentor(Mentor mentor);       //更改信息
    List<RecruitmentInfo> getRecruitmentInfoByTeacherId(String teacherId) throws SQLException; //导师招生指标
    List<StudentAC> getAllStudentsByCollegeId(String collegeId);        //本学院全部录取学生名单
}
