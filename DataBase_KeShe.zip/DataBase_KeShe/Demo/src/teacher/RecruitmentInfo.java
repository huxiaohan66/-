package teacher;


public class RecruitmentInfo {
    private String teacherId;
    private String teacherName;
    private String collegeId;
    private String subjectId;
    private String teacherIdentity;
    private int quota;
    private int vacancy;
    private String subjectName;
    private String collegeName;

    // Constructor
    public RecruitmentInfo() {
    }

    // Getters and Setters
    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getCollegeId() {
        return collegeId;
    }

    public void setCollegeId(String collegeId) {
        this.collegeId = collegeId;
    }

    public String getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

    public String getTeacherIdentity() {
        return teacherIdentity;
    }

    public void setTeacherIdentity(String teacherIdentity) {
        this.teacherIdentity = teacherIdentity;
    }

    public int getQuota() {
        return quota;
    }

    public void setQuota(int quota) {
        this.quota = quota;
    }

    public int getVacancy() {
        return vacancy;
    }

    public void setVacancy(int vacancy) {
        this.vacancy = vacancy;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "RecruitmentInfo{" +
                "teacherId='" + teacherId + '\'' +
                ", teacherName='" + teacherName + '\'' +
                ", collegeId='" + collegeId + '\'' +
                ", subjectId='" + subjectId + '\'' +
                ", teacherIdentity='" + teacherIdentity + '\'' +
                ", quota=" + quota +
                ", vacancy=" + vacancy +
                ", subjectName='" + subjectName + '\'' +
                ", collegeName='" + collegeName + '\'' +
                '}';
    }
}