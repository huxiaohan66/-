package teacher;

public class Mentor {
    private String mentorId;
    private String name;
    private String title;
    private String department1;
    private String department2;
    private String department3;
    private String phone;
    private String email;
    private String bio;
    private String image;
    private String college;

    // Constructor
    public Mentor() {
    }

    // Getters and Setters
    public String getMentorId() {
        return mentorId;
    }

    public void setMentorId(String mentorId) {
        this.mentorId = mentorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDepartment1() {
        return department1;
    }

    public void setDepartment1(String department1) {
        this.department1 = department1;
    }

    public String getDepartment2() {
        return department2;
    }

    public void setDepartment2(String department2) {
        this.department2 = department2;
    }

    public String getDepartment3() {
        return department3;
    }

    public void setDepartment3(String department3) {
        this.department3 = department3;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "Mentor{" +
                "mentorId='" + mentorId + '\'' +
                ", name='" + name + '\'' +
                ", title='" + title + '\'' +
                ", department1='" + department1 + '\'' +
                ", department2='" + department2 + '\'' +
                ", department3='" + department3 + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", bio='" + bio + '\'' +
                ", image='" + image + '\'' +
                ", college='" + college + '\'' +
                '}';
    }
}