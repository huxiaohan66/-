package connect;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TOOL {

    public static boolean checkexist(String teacherId, String subjectId) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean exists = false;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT 1 FROM 导师次序表 WHERE 导师编号=? AND 学科编号=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, teacherId);
            ps.setString(2, subjectId);
            rs = ps.executeQuery();
            if (rs.next()) {
                exists = true; // 如果查询结果不为空，说明存在记录
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return exists;
    }

    public static int checkIfSubmitted(String teacherId, String subjectId) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int isSubmitted = -1;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT 是否提交 FROM dbo.导师次序表 WHERE 导师编号=? AND 学科编号=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, teacherId);
            ps.setString(2, subjectId);
            rs = ps.executeQuery();
            if (rs.next()) {
                isSubmitted = rs.getInt("是否提交");
                // 1 提交  0未提交
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return isSubmitted;
    }

    // 获取最后一个序号
    public static int getLastSequenceNumber(String teacherId, String subjectId) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int SequenceNumber = 0;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT 序号 FROM 导师次序表 WHERE 导师编号=? AND 学科编号=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, teacherId);
            ps.setString(2, subjectId);
            rs = ps.executeQuery();
            if (rs.next()) {
                SequenceNumber = rs.getInt("序号");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return SequenceNumber;
    }

    // 检查上一行是否提交
    public static int checkPreviousRowSubmitted(String teacherId, String subjectId, int sequenceNumber) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int isPreviousRowSubmitted=2;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT 是否提交 FROM dbo.导师次序表 WHERE  学科编号=? AND 序号=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, subjectId);
            ps.setInt(2, sequenceNumber - 1);
            rs = ps.executeQuery();
            if (rs.next()) {
                isPreviousRowSubmitted = rs.getInt("是否提交") ; // 如果返回0，表示未提交
                // TRUE 未提交 -- FALSE 已提交
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
        return isPreviousRowSubmitted;
    }
}