package tool;




import java.sql.SQLException;
import java.util.List;

public interface ToolDAO {
    List<Integer> getRoundStatuses();   //获取轮次状态
    List<String> getSubjects(String teacherId) throws SQLException;     //导师负责哪些学科编号
    List<stu> getFirstChoicestus(String subjectId, String teacherName) throws Exception;//一志愿学生
    List<stu> getSecondChoicestus(String subjectId, String teacherName) throws SQLException; //二志愿学生
    List<stu> getThirdChoicestus(String subjectId, String teacherName) throws Exception; //三志愿学生
    List<stu> getConfirmedstus(String subjectId) throws Exception;//剩下的学生
    int checkfirstround(String teacherId) throws Exception; //一轮资格
    int checkround3(String teacherId) throws Exception;//三轮资格
    boolean checkround2(String teacherId) throws Exception;     //二轮资格
    List<teacherturn> getTeachersOrderBySubjectId(String subjectId) throws Exception;       //导师次序表
}

