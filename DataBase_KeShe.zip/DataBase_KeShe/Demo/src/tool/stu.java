package tool;

public class stu {
    private String studentId;
    private String studentName;

    // Constructor, getters, and setters
    public stu(String studentId, String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
    }

    public String getstuId() {
        return studentId;
    }

    public String getstuName() {
        return studentName;
    }
}
