package tool;

import connect.JDBCUtils;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class ToolDAOImpl implements ToolDAO {
    @Override
    public List<Integer> getRoundStatuses() {   //获取轮次状态
        List<Integer> roundStatuses = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql = "SELECT 一轮, 二轮, 三轮 FROM 轮次表";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                // 假设数据库中的列名就是“一轮”，“二轮”，“三轮”
                roundStatuses.add(rs.getInt("一轮"));
                roundStatuses.add(rs.getInt("二轮"));
                roundStatuses.add(rs.getInt("三轮"));
            }
        } catch (Exception e) {
            e.printStackTrace(); // 在实际项目中，应该记录日志而不是打印堆栈跟踪
        } finally {
            JDBCUtils.closeResource(conn, ps, rs);
        }
        return roundStatuses;
    }
    @Override
    public List<String> getSubjects(String teacherId) throws SQLException {     //获取某老师负责的学科编号
        List<String> subjects = new ArrayList<>();
        String sql = "SELECT 学科编号 FROM 导师表 WHERE 导师编号 = ?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, teacherId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    subjects.add(rs.getString("学科编号"));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return subjects;
    }

    @Override           //获取一志愿学生
    public List<stu> getFirstChoicestus(String subjectId, String teacherName) throws Exception {
        List<stu> students = new ArrayList<>();
        String sql = "SELECT 学生编号, 学生姓名 FROM 学生志愿表 WHERE 报考学科编号 = ? AND 导师姓名_第一志愿 = ?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, subjectId);
            ps.setString(2, teacherName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    students.add(new stu(rs.getString("学生编号"), rs.getString("学生姓名")));
                }
            }
        }
        return students;
    }

    @Override           //获取二志愿学生
    public List<stu> getSecondChoicestus(String subjectId, String teacherName) throws SQLException {
        List<stu> students = new ArrayList<>();
        String sql = "SELECT 学生编号, 学生姓名 FROM 学生志愿表 WHERE 报考学科编号 = ? AND 导师姓名_第二志愿 = ?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, subjectId);
            ps.setString(2, teacherName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    students.add(new stu(rs.getString("学生编号"), rs.getString("学生姓名")));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return students;
    }

    @Override           //获取三志愿学生
    public List<stu> getThirdChoicestus(String subjectId, String teacherName) throws Exception {
        List<stu> students = new ArrayList<>();
        String sql = "SELECT 学生编号, 学生姓名 FROM 学生志愿表 WHERE 报考学科编号 = ? AND 导师姓名_第三志愿 = ?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, subjectId);
            ps.setString(2, teacherName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    students.add(new stu(rs.getString("学生编号"), rs.getString("学生姓名")));
                }
            }
        }
        return students;
    }
    @Override           //没有被选择的学生
    public List<stu> getConfirmedstus(String subjectId) throws Exception {
        List<stu> students = new ArrayList<>();
        String sql = "SELECT 学生编号, 学生姓名 FROM 未匹配学生名单 WHERE 学科编号=? ";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, subjectId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    students.add(new stu(rs.getString("学生编号"), rs.getString("学生姓名")));
                }
            }
        }
        return students;
    }

    @Override       //是否可以参加一轮选择
    public int checkfirstround(String teacherId) throws Exception {
        String sql = "SELECT 是否被学生选择 FROM 导师表 WHERE  导师编号 =?";
        int index=0;
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, teacherId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    index=rs.getInt("是否被学生选择");
                    if(index!=0){
                        break;
                    }
                }
            }
        }
        return index;
    }

    @Override           //是否可以参加二轮
    public boolean checkround2(String teacherId) throws Exception{
        String sql = "SELECT 是否被学生选择 FROM 导师表 WHERE  导师编号 =?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, teacherId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                   if(rs.getInt("是否被学生选择")==0)
                        return true;
                }
            }
        }
        return false;
    }
    @Override       //是否可以参加三轮
    public int checkround3(String teacherId) throws Exception{
        String sql = "SELECT 缺额数 FROM 导师表 WHERE  导师编号 =?";
        int index=0;
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, teacherId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    index=rs.getInt("缺额数");
                    if(index!=0){
                        break;
                    }
                }
            }
        }
        return index;
    }

    @Override           //查看导师次序表
    public List<teacherturn> getTeachersOrderBySubjectId(String subjectId) throws Exception{
        List<teacherturn> teachers = new ArrayList<>();
        String sql = "SELECT 导师次序表.序号, 导师次序表.导师编号, 导师信息表.导师姓名, 导师次序表.是否提交 " +
                "FROM 导师次序表 INNER JOIN 导师信息表 ON 导师次序表.导师编号 = 导师信息表.导师编号 " +
                "WHERE 导师次序表.学科编号=?;";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, subjectId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    teacherturn teacher = new teacherturn();
                    teacher.setSequence(rs.getInt("序号"));
                    teacher.setTeacherId(rs.getString("导师编号"));
                    teacher.setTeacherName(rs.getString("导师姓名"));
                    teacher.setIsSubmitted(rs.getInt("是否提交"));
                    teachers.add(teacher);

                }
            }
        }
        return teachers;
    }
}
