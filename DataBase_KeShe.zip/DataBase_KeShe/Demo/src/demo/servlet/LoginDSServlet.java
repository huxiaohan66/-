package demo.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connect.JDBCUtils;

@WebServlet("/LoginDSServlet")
public class  LoginDSServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish connection using JDBCUtils
            conn = JDBCUtils.getConnection();
            String sql = "SELECT * FROM 学科秘书登录表 WHERE 学科秘书编号 = ? AND 密码 = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Login success, set session attributes
            	String collegeId = rs.getString("所属学院编号");
                System.out.println("College ID from database in LoginDSServlet: " + collegeId); // 打印调试信息
                if (collegeId != null) {
                    HttpSession session = request.getSession();
                    session.setAttribute("username", username);
                    session.setAttribute("collegeId", collegeId); // 将 collegeId 存入会话
                    response.sendRedirect("DisciplineSecretaryDashboard.jsp");
                } else {
                    System.out.println("Error: College ID is null in LoginDSServlet");
                    response.sendRedirect("Login.jsp?error=4");
                }
            } else {
                // Login failure, redirect to login page with error
                response.sendRedirect("Login.jsp?error=1");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Login.jsp?error=2");
        } finally {
            // Close resources using JDBCUtils
            JDBCUtils.closeResource(conn, stmt, rs);
        }
    }

}
