package demo.servlet;


import teacher.MentorDAO;
import teacher.MentorDAOImpl;
import teacher.Mentor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UpdateTeacherInfoServlet", value = "/UpdateTeacherInfoServlet")
public class UpdateTeacherInfoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 如果需要处理GET请求，可以在这里添加代码
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        // 获取请求参数
        String teacherId = request.getParameter("teacherId");
        String teacherName = request.getParameter("teacherName");
        String teacherTitle = request.getParameter("teacherTitle");
        String subject1 = request.getParameter("subject1");
        String subject2 = request.getParameter("subject2");
        String subject3 = request.getParameter("subject3");
        String teacherPhone = request.getParameter("teacherPhone");
        String teacherEmail = request.getParameter("teacherEmail");
        String teacherIntroduction = request.getParameter("teacherIntroduction");

        // 创建Mentor对象
        Mentor mentor = new Mentor();
        mentor.setMentorId(teacherId);
        mentor.setName(teacherName);
        mentor.setTitle(teacherTitle);
        mentor.setDepartment1(subject1);
        mentor.setDepartment2(subject2);
        mentor.setDepartment3(subject3);
        mentor.setPhone(teacherPhone);
        mentor.setEmail(teacherEmail);
        mentor.setBio(teacherIntroduction);

        // 使用DAO更新导师信息
        try {
            MentorDAO mentorDAO = new MentorDAOImpl();
            mentorDAO.updateMentor(mentor);
            response.sendRedirect("teacherchoice1.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Error updating teacher information", e);
        }
    }
}