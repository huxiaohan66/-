package demo.servlet;

import connect.JDBCUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@WebServlet(name = "MentorOrderServlet", urlPatterns = "/MentorOrderServlet")
public class MentorOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String teacherId = request.getParameter("teacherId");

        Connection con = null;
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        ResultSet rs = null;

        try {
            con = JDBCUtils.getConnection();
            String sqltruncate = "TRUNCATE TABLE 导师次序表";
            ps1 = con.prepareStatement(sqltruncate);
            ps1.executeUpdate();
            ps1.close();

            // 根据teacherId获取学院编号
            String getCollegeIdSql = "SELECT 学院编号 FROM 导师表 WHERE 导师编号 = ?";
            ps = con.prepareStatement(getCollegeIdSql);
            ps.setString(1, teacherId);
            rs = ps.executeQuery();
            String collegeId = null;
            if (rs.next()) {
                collegeId = rs.getString("学院编号");
            }

            // 遍历导师表，将该学院的所有学科编号存入一个列表
            List<String> subjectIds = new ArrayList<>();
            String getSubjectIdsSql = "SELECT DISTINCT 学科编号 FROM 导师表 WHERE 学院编号 = ?";
            ps = con.prepareStatement(getSubjectIdsSql);
            ps.setString(1, collegeId);
            rs = ps.executeQuery();
            while (rs.next()) {
                subjectIds.add(rs.getString("学科编号"));
            }

            // 根据学科编号查询老师，并根据缺额数降序排序
            String insertMentorOrderSql = "INSERT INTO 导师次序表 (序号, 导师编号, 是否提交, 学院编号, 学科编号) VALUES (?, ?, '0', ?, ?)";
            ps = con.prepareStatement(insertMentorOrderSql);

            for (String subjectId : subjectIds) {
                int sequenceNumber = 1; // 初始化序号
                String getMentorsSql = "SELECT 导师编号, 缺额数 FROM 导师表 WHERE 学科编号 = ? ORDER BY 缺额数 DESC";
                PreparedStatement getMentorsPs = con.prepareStatement(getMentorsSql);
                getMentorsPs.setString(1, subjectId);
                ResultSet getMentorsRs = getMentorsPs.executeQuery();

                // 存储具有相同缺额数的导师
                Map<Integer, List<String>> mentorsByQuota = new HashMap<>();
                while (getMentorsRs.next()) {
                    int quota = getMentorsRs.getInt("缺额数");
                    String mentorId = getMentorsRs.getString("导师编号");
                    mentorsByQuota.computeIfAbsent(quota, k -> new ArrayList<>()).add(mentorId);
                }
                getMentorsPs.close();
                getMentorsRs.close();

                // 对每个缺额数的导师列表进行随机排序
                for (List<String> mentorList : mentorsByQuota.values()) {
                    Collections.shuffle(mentorList);
                }

                // 插入导师信息
                // 首先对Map中的Entry集合按照缺额数进行排序，确保缺额数由多到少
                List<Map.Entry<Integer, List<String>>> sortedEntries = new ArrayList<>(mentorsByQuota.entrySet());
                sortedEntries.sort((o1, o2) -> o2.getKey().compareTo(o1.getKey()));

                for (Map.Entry<Integer, List<String>> entry : sortedEntries) {
                    // 对相同缺额数的导师列表进行随机排序
                    Collections.shuffle(entry.getValue());
                    for (String mentorId : entry.getValue()) {
                        ps.setInt(1, sequenceNumber++);
                        ps.setString(2, mentorId);
                        ps.setString(3, collegeId);
                        ps.setString(4, subjectId);
                        ps.addBatch();
                    }
                }
            }

            // 执行批量插入
            ps.executeBatch();
            response.getWriter().write("导师次序表更新成功！");
            //response.sendRedirect("teachercheck2.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("数据库操作失败：" + e.getMessage());
        } finally {
            JDBCUtils.closeResource(con, ps, rs);
        }
    }
}
 