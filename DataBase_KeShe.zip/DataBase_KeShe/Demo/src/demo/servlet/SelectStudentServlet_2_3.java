package demo.servlet;

import connect.JDBCUtils;
import connect.TOOL;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SelectStudentServlet_2_3", value = "/SelectStudentServlet_2_3")
public class SelectStudentServlet_2_3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String teacherId = request.getParameter("teacherId");
        String studentId = request.getParameter("studentId");
        String subjectId = request.getParameter("subjectId");
        int isSubmitted ;
        int previousRowSubmitted ;
        int previousSequenceNumber ;
        boolean exists=TOOL.checkexist(teacherId, subjectId);
        if(!exists){
            request.setAttribute("message", "该学科暂时没有提交权限");
        }
        else {
            if (studentId != "") {
                isSubmitted = TOOL.checkIfSubmitted(teacherId, subjectId);
                if (isSubmitted == 1) {
                    request.setAttribute("message", "已经提交过了");
                } else if (isSubmitted == 0) {
                    previousSequenceNumber = TOOL.getLastSequenceNumber(teacherId, subjectId);
                    previousRowSubmitted = TOOL.checkPreviousRowSubmitted(teacherId, subjectId, previousSequenceNumber);
                    if (previousRowSubmitted == 0) {
                        request.setAttribute("message", "上一个人还没有提交，请等待");
                    } else {
                        Connection con = null;
                        PreparedStatement ps = null;
                        ResultSet rs = null;
                        String priority = "1"; // 即选即中

                        try {
                            con = JDBCUtils.getConnection();
                            // 检查学生是否已经被选择
                            String checkSql = "SELECT 状态 FROM 复试通过学生导师匹配表 WHERE 学生编号 = ? ";
                            ps = con.prepareStatement(checkSql);
                            ps.setString(1, studentId);
                            rs = ps.executeQuery();
                            if (rs.next()) {
                                int currentPriority = rs.getInt("状态");
                                if (currentPriority == 0) {
                                    String updateSql = "UPDATE 复试通过学生导师匹配表 SET 导师编号 = ?, 状态 = ? WHERE 学生编号 = ? ";
                                    ps = con.prepareStatement(updateSql);
                                    ps.setString(1, teacherId);
                                    ps.setString(2, priority);
                                    ps.setString(3, studentId);
                                    ps.executeUpdate();

                                    String updateSql2 = "UPDATE 导师次序表 SET 是否提交 = 1 WHERE 导师编号 = ? and 学科编号=?";

                                    PreparedStatement ps1 = con.prepareStatement(updateSql2);
                                    ps1.setString(1, teacherId);
                                    ps1.setString(2, subjectId);
                                    ps1.executeUpdate();
                                    ps1.close();

                                    request.setAttribute("message", "提交成功");
                                } else {
                                    request.setAttribute("message", "提交失败（学生被抢走啦）");
                                }
                            } else {
                                request.setAttribute("message", "系统出错啦");
                            }

                        } catch (SQLException e) {
                            e.printStackTrace();
                            System.out.println("Error message: " + e.getMessage());
                            System.out.println("Error code: " + e.getErrorCode());
                            response.getWriter().write(studentId + "   " + priority + teacherId);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        } finally {
                            JDBCUtils.closeResource(con, ps, rs);
                        }
                    }
                } else {
                    request.setAttribute("message", "您已经选满啦");
                }
            } else {
                request.setAttribute("message", "提交成功(空值)");
            }
        }
        request.getRequestDispatcher("teacherselect2&3.jsp").forward(request, response);
    }
}
