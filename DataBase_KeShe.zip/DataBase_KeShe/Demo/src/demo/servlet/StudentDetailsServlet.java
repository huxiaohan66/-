package demo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.StudentDAO;
import model.Student;

@WebServlet("/StudentDetailsServlet")
public class StudentDetailsServlet extends HttpServlet {

	private StudentDAO studentDao = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String collegeId = (String) session.getAttribute("collegeId");

        
        if (collegeId != null) {
            List<Student> students = studentDao.getStudentsByCollege(collegeId);
            request.setAttribute("students", students);
            request.getRequestDispatcher("/StudentDetails.jsp").forward(request, response);
        } else {
            response.sendRedirect("Login.jsp?error=3");
        }
    }


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
