package demo.servlet;

import connect.JDBCUtils;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "GetTeacherLogin", value = "/GetTeacherLogin")
public class GetTeacherLogin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        // 获取表单数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 连接数据库
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = JDBCUtils.getConnection();
            String sql = "SELECT * FROM 导师登录表 WHERE 导师编号 = ? AND 密码 = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();

            // 检查用户名和密码是否匹配
            if (rs.next()) {
                // 登录成功
                HttpSession session = request.getSession();

                // 从导师登录表获取导师编号
                String teacherId = rs.getString("导师编号");

                // 从导师信息表查询导师姓名和所属学院
                String queryInfoSql = "SELECT 导师姓名, 学院表.学院名称 , 学院表.学院编号 FROM 导师信息表 INNER JOIN 学院表 ON 学院表.学院编号=导师信息表.所属学院 WHERE 导师编号 = ?";
                PreparedStatement infoPs = con.prepareStatement(queryInfoSql);
                infoPs.setString(1, teacherId);
                ResultSet infoRs = infoPs.executeQuery();

                if (infoRs.next()) {
                    String teacherName = infoRs.getString("导师姓名");
                    String teacherCollege = infoRs.getString("学院名称");
                    String CollegeId=infoRs.getString("学院编号");
                    // 存储导师信息到会话中
                    session.setAttribute("teacherId", teacherId);
                    session.setAttribute("teacherName", teacherName);
                    session.setAttribute("teacherCollege", teacherCollege);
                    session.setAttribute("CollegeId", CollegeId);
                }

                // 关闭
                JDBCUtils.closeResource(null, infoPs, infoRs);

                // 重定向到导师的主页
                response.sendRedirect("teacher.jsp");
            } else {
                // 登录失败
                request.setAttribute("errorMessage", "用户名或密码错误");
                request.getRequestDispatcher("teacherlogin.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("数据库连接失败：" + e.getMessage());
        } finally {
            // 关闭资源
            JDBCUtils.closeResource(con, ps, rs);
        }
    }
}
 