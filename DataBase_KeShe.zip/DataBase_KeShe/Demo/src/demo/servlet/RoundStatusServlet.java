package demo.servlet;

import tool.ToolDAO;
import tool.ToolDAOImpl;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RoundStatusServlet")
public class RoundStatusServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String roundParam = request.getParameter("round");
        int roundNumber = 0;
        try {
            roundNumber = Integer.parseInt(roundParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid round number.");
            return;
        }

        ToolDAO toolDAO = new ToolDAOImpl();
        String teacherId = (String) request.getSession().getAttribute("teacherId");
        int index1 = 0;
        int index3 = 0;
        boolean flag;
        try {
            index1 = toolDAO.checkfirstround(teacherId);
            flag=toolDAO.checkround2(teacherId);
            index3 = toolDAO.checkround3(teacherId);
        } catch (Exception e) {
            throw new ServletException("Error checking round status", e);
        }

        // 根据轮次编号跳转到对应的JSP页面或显示错误消息
        switch (roundNumber) {
            case 1:
                if (index1 == 1) {
                    response.sendRedirect("teacherselect1.jsp");
                } else {
                    response.sendRedirect("teacherchoice3.jsp?message=no_permission_round1");
                }
                break;
            case 2:
                if(flag){
                    response.sendRedirect("teachercheck.jsp");
                }else {
                    response.sendRedirect("teacherchoice3.jsp?message=no_permission_round2");
                }
                break;
            case 3:
                if (index3 != 0) {
                        response.sendRedirect("teachercheck.jsp");
                } else {
                        response.sendRedirect("teacherchoice3.jsp?message=no_permission_round3");
                }
                break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid round number.");
                break;
        }
    }
}