package demo.servlet;

import connect.JDBCUtils;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SelectStudentServlet", value = "/SelectStudentServlet")
public class SelectStudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String teacherId = request.getParameter("teacherId");
        String studentId = request.getParameter("studentId");
        String subjectId = request.getParameter("subjectId");

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String priority = null; // 默认值

        try {
            con = JDBCUtils.getConnection();

            // 获取状态和导师ID
            String checkSql = "SELECT 状态,导师编号 FROM 复试通过学生导师匹配表 WHERE 学生编号 = ? ";
            ps = con.prepareStatement(checkSql);
            ps.setString(1, studentId);
            rs = ps.executeQuery();
            int currentPriority = 0;
            String id=null;
            if (rs.next()) {
                currentPriority = rs.getInt("状态");
                id=rs.getString("导师编号");
            }
            ps.close();
            rs.close();

            // 获取志愿优先级
            String prioritySql = "SELECT CASE " +
                    "WHEN 学生志愿表.导师姓名_第一志愿 = 导师姓名 THEN '1' " +
                    "WHEN 学生志愿表.导师姓名_第二志愿 = 导师姓名 THEN '2' " +
                    "WHEN 学生志愿表.导师姓名_第三志愿 = 导师姓名 THEN '3' " +
                    "ELSE '0' " +
                    "END AS 志愿顺序 " +
                    "FROM 学生志愿表 " +
                    "CROSS JOIN " +
                    "(SELECT 导师姓名 FROM 导师表 WHERE 导师编号 = ?) AS 导师姓名 " +
                    "WHERE 学生志愿表.学生编号 = ?";

            ps = con.prepareStatement(prioritySql);
            ps.setString(1, teacherId);
            ps.setString(2, studentId);
            rs = ps.executeQuery();
            if (rs.next()) {
                priority = rs.getString("志愿顺序");
            }
            ps.close();
            rs.close();

            //获取 一轮选择数，导师数
            String check = "select 一轮选择数 ,导师指标 From 导师表  WHERE 导师编号 = ? and 学科编号=?";
            ps = con.prepareStatement(check);
            ps.setString(1, teacherId);
            ps.setString(2, subjectId);
            rs = ps.executeQuery();
            int a=0;
            int b=0;
            if (rs.next()) {
                a = rs.getInt("一轮选择数");
                b=rs.getInt("导师指标");
            }
            ps.close();
            rs.close();



            if (priority != null && (currentPriority == 0 || currentPriority > Integer.parseInt(priority))&&(a<b))  {
                String updateSql = "UPDATE 复试通过学生导师匹配表 SET 导师编号 = ?, 状态 = ? WHERE 学生编号 = ? ";
                ps = con.prepareStatement(updateSql);
                ps.setString(1, teacherId);
                ps.setString(2, priority);
                ps.setString(3, studentId);
                ps.executeUpdate();
                ps.close();

                String updateMentorSql = "UPDATE 导师表 SET 一轮选择数 = 一轮选择数 + 1 WHERE 导师编号 = ? and 学科编号=?";
                ps = con.prepareStatement(updateMentorSql);
                ps.setString(1, teacherId);
                ps.setString(2, subjectId);
                ps.executeUpdate();
                ps.close();

                //response.sendRedirect("teacherchoice3.jsp");
                request.setAttribute("message","提交成功");
                request.getRequestDispatcher("teacherselect1.jsp").forward(request, response);
                //response.getWriter().write(currentPriority + "   " + priority +  subjectId+teacherId+"charuchenggong");
            }

            else if(a>=b){
                request.setAttribute("message","提交失败，选择人数超过指标数"+a+" "+b+" "+teacherId+" "+subjectId+"   ??");
                request.getRequestDispatcher("teacherselect1.jsp").forward(request, response);
            } else if (id.equals(teacherId)) {
                request.setAttribute("message","提交失败，已经选过该学生了"+id+" "+teacherId);
                request.getRequestDispatcher("teacherselect1.jsp").forward(request, response);
            }else {
                request.setAttribute("message","提交失败，学生被选走了");
                request.getRequestDispatcher("teacherselect1.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error message: " + e.getMessage());
            System.out.println("Error code: " + e.getErrorCode());
            request.setAttribute("message",e.getMessage());
            request.getRequestDispatcher("teacherselect1.jsp").forward(request, response);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            JDBCUtils.closeResource(con, ps, rs);

        }
    }
}