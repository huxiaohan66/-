package demo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MentorDAO;
import model.Mentor;

@WebServlet("/MentorDetailsServlet")
public class MentorDetailsServlet extends HttpServlet {
	private MentorDAO mentorDao = new MentorDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// 从会话中获取 collegeId
        HttpSession session = request.getSession();
        String collegeId = (String) session.getAttribute("collegeId");
        //HttpSession session = request.getSession();
        System.out.println("Session ID in MentorServlet: " + session.getId());
        //String collegeId = (String) session.getAttribute("collegeId");
        System.out.println("College ID in MentorServlet: " + collegeId); // 调试输出

        if (collegeId != null) {
            // 使用 collegeId 查询导师信息
            List<Mentor> mentors = mentorDao.getAllMentorsByCollege(collegeId);
            System.out.println("Mentors list size: " + mentors.size());
            request.setAttribute("mentors", mentors); // 设置导师列表作为请求属性
            request.getRequestDispatcher("/MentorDetails.jsp").forward(request, response);
        } else {
            // 如果没有 collegeId，重定向到登录页面或显示错误
            response.sendRedirect("Login.jsp?error=3"); // 您可以自定义错误代码
        }
    }

}
